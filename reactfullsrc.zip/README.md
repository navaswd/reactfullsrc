# react-id-swiper
react-id-swiper example with reactjs Component
Do wwith react reactjs with react-id-swiper
