import React from 'react';
import ReactDOM from 'react-dom';
import SampleContainer from './containers/sampleContainer';
import '../assets/sass/index.scss';

ReactDOM.render(<SampleContainer />, document.getElementById('root'));
