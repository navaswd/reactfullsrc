import React from 'react';
import { Button } from 'react-bootstrap';
import Magnifier from 'react-magnifier';
import  testimage from '../../../assets/images/testimage.jpg';
import thumb from '../../../assets/images/thumb.jpg';
import ReactTimeout from 'react-timeout';
import Swiper from 'react-id-swiper';
import '../../../node_modules/react-id-swiper/src/styles/css/swiper.css';
import '../../../node_modules/react-id-swiper/src/styles/scss/swiper.scss';
import './style.scss';

class SampleContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isAnimationEnabled: '',
            isHovered: false

        };
    }
    goNext = () => {
        if (this.swiper) this.swiper.slideNext()
    }
    componentDidMount() {
        setTimeout(() => {
            this.setState({
                isAnimationEnabled: 'active'
            })
        }, 2000);
    }

    componentWillUnmount() {
        alert('UNMOUNT')
    }
    handleHoveron=()=>{       
        this.setState({ isHovered: true });
      }
      handleHoveroff=()=>{         
        this.setState({ isHovered: false });    
      }
    render() {
        const params = {
            direction: 'vertical',
            speed: 1000,
            slidePerView: 1,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            spaceBetween: 0,
            simulateTouch: true,
            keyboard: {
                enabled: true,
            },
            mousewheel: true
        }
      //  const hoverClass = this.state.isHovered ? "slider_hover" : "";
        return (

            <div className="swiper-container">
                <Swiper {...params} ref={node => { if (node) this.swiper = node.swiper }}>
                    <div className="style1">
                        <p>Slide 1</p>
                        <Button bsStyle="primary" className="button_down" onClick={() => this.goNext()} >Down</Button>
                    </div>
                    <div className="style2">
                        <div id="view">
                            <div id="frame">
                               
                                <div className="op-section second">section1 

                                <ul className={"gaf-roof " + this.state.isAnimationEnabled}>
                                    <li>
                                        <h3>Leak Barrier</h3>
                                        <span>1</span>
                                    </li>
                                    <li>
                                        <h3>Roof Deck Protection</h3>
                                        <span>2</span>
                                    </li>
                                    <li>
                                        <h3>Starter Strip Shingles</h3>
                                        <span>3</span>
                                    </li>
                                    <li>
                                        <h3>Lifetime Shingles</h3>
                                        <span>4</span>
                                    </li>
                                    <li>
                                        <h3>Cobra Attic Venitlation</h3>
                                        <span>5</span>
                                    </li>
                                    <li class="pickpoint">
                                        <h3>Ridge Cap Shingles</h3>
                                        <span>6</span>
                                    </li>
                                </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="style3">                        
                        <Magnifier src="images/testimage.jpg" width="100%" height="100%" zoomFactor="2.5"/>
                    </div>
                    <div className="style4">
                        <div class="container">
                        <h1>Slider Animation</h1>
                            <div class="slider-animblock">
                                <div className={this.state.isHovered ? "slider-left slider_hover" : "slider-left"}>
                                    <div class="slider-content text-center">
                                        <h2>Personal content</h2>
                                        <p>HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries</p>
                                        <span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span>
                                    </div>
                                    <div class="slider-hovershow">
                                        <div class="show-left text-center">
                                            <h2>Show after Hover</h2>
                                            <p>HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries</p>
                                            <button type="button" class="btn btn-default">Submit</button>
                                        </div>
                                        <div class="show-right text-center">
                                            <h2>Show after Hover</h2>
                                            <p>HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries</p>
                                            <button type="button" class="btn btn-default">Submit</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="slider-right" onMouseEnter={()=>this.handleHoveron()} onMouseLeave={()=>this.handleHoveroff()}>
                                    <div class="slider-content text-center">
                                        <h2>Personal content</h2>
                                        <p>HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries</p>
                                        <span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span>
                                    </div>
                                    <div class="slider-hovershow">
                                        <div class="show-left text-center">
                                            <h2>Show after Hover</h2>
                                            <p>HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries</p>
                                            <button type="button" class="btn btn-default">Submit</button>
                                        </div>
                                        <div class="show-right text-center">
                                            <h2>Show after Hover</h2>
                                            <p>HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries</p>
                                            <button type="button" class="btn btn-default">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="style5">
                        <div class="container">
                        <h1>Box Animation</h1>
                            <div class="box-image">
                                <img src={thumb} width="300" height="300" />
                                <div class="box-border"></div>
                                <div class="box-title">
                                    <h3>
                                        <span>Choose with</span>
                                        <span>Confidence</span>
                                    </h3>
                                    <div class="box-hover-visible">
                                        <span class="box-line"></span>
                                        <p>Tips for finding the right shingle</p>
                                        <a href="" classs="lmore">
                                            Learn More
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="style6">

                    </div>
                </Swiper>
            </div>

        );
    }
}

export default SampleContainer;
